TOKEN = "8085016643:AAH0-3wNlvv89wOWxaO6uMMQD6h7jzMkowE"  # ضع هنا التوكن الخاص بك
ADMIN_USER_IDS = [953696547, 7942066919]  # ضع هنا معرفات المستخدمين المشرفين